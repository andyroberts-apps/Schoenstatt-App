# Schoenstatt — Covenant of Love

A prayer book and Spiritual Daily Order app for the Schoenstatt Movement.
Built with React + Vite. Ships as a PWA and native iOS/Android app via Capacitor.

---

## Step 1 — Deploy the web app (required before app stores)

### Option A: Vercel (recommended, free)
1. Push this folder to a new GitHub repository
2. Go to vercel.com and sign in with GitHub
3. Click "Add New Project" and import your repository
4. Leave all settings as defaults (Vercel detects Vite automatically)
5. Click "Deploy" — live HTTPS URL in ~60 seconds

### Option B: Netlify (also free)
1. Push this folder to GitHub
2. Netlify.com -> "Add new site" -> "Import from Git"
3. Build command: npm run build
4. Publish directory: dist
5. Click "Deploy site"

---

## Step 2 — Install as a PWA (optional but instant)

Once deployed to HTTPS, users can install directly from their browser:
- iPhone: Open in Safari -> Share button -> "Add to Home Screen"
- Android: Open in Chrome -> three-dot menu -> "Add to Home Screen"

---

## Step 3 — Build for app stores with Capacitor

### Prerequisites
- Node.js 18+
- Android: Android Studio
- iOS: Xcode (Mac only) + Apple Developer account ($99/year)

### Initial setup
  npm install
  npm run build

### Android (Google Play — $25 one-time fee)
  npm run cap:add:android     # first time only
  npm run cap:sync
  npm run cap:open:android    # opens Android Studio

In Android Studio:
1. Build -> Generate Signed Bundle / APK -> Android App Bundle (.aab)
2. Create a keystore (save it — needed for every future update)
3. Upload .aab to Google Play Console (play.google.com/console)

### iOS (App Store — $99/year Apple Developer account)
  npm run cap:add:ios         # first time only
  npm run cap:sync
  npm run cap:open:ios        # opens Xcode

In Xcode:
1. Set your Team under Signing & Capabilities
2. Set Bundle Identifier (e.g. com.yourname.schoenstatt)
3. Product -> Archive -> Distribute App -> App Store Connect
4. Submit for review at appstoreconnect.apple.com
   (Review typically takes 1-3 days)

---

## After every update
  npm run build
  npm run cap:sync
Then re-archive from Xcode / re-bundle from Android Studio.

---

## Run locally
  npm install
  npm run dev
  Open http://localhost:5173

---

## Adding audio to prayers

In src/App.jsx, find the prayer in the PRAYERS array and set audioUrl:

  audioUrl: "https://your-host.com/prayer-name.mp3"

Recommended hosts: Google Drive, Dropbox, Cloudflare R2, Amazon S3

---

## App store listing (suggested copy)

Name: Schoenstatt — Covenant of Love
Subtitle: Prayer Book & Spiritual Daily Order
Category: Reference / Lifestyle
Keywords: Schoenstatt, Catholic, prayer, Marian, daily order, devotional, Kentenich

Description:
A devotional companion for the Schoenstatt Movement. Contains the complete
Heavenwards prayer book with 29 prayers by Father Joseph Kentenich, and a
personal Spiritual Daily Order (SDO) checklist that resets each day.
Optional reminders at noon and 8pm support your daily practice.
